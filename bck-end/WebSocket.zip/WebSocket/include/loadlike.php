﻿<?php
if($_SERVER["REQUEST_METHOD"] == "POST"){
	include "db_connect.php";
	
	$id = $_POST["id"];
	
	$result = mysql_query("SELECT likke FROM cart WHERE id='$id'", $link);
	
	if (mysql_num_rows($result) > 0){
		$row = mysql_fetch_array($result);
		do{
			$count = $count + $row["likke"];
		}
		while($row = mysql_fetch_array($result));
		echo $count;
	} else {
		echo '0';
	}
}
?>