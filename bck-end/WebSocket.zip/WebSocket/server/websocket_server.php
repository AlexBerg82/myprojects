<?php
set_time_limit(0);

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;
use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;

require_once '../vendor/autoload.php';

class Chat implements MessageComponentInterface {
	protected $clients;
	protected $users;

	public function __construct() {
		$this->clients = new \SplObjectStorage;
	}

	public function onOpen(ConnectionInterface $conn) {
		$this->clients->attach($conn);
		// $this->users[$conn->resourceId] = $conn;
	}

	public function onClose(ConnectionInterface $conn) {
		$this->clients->detach($conn);
		// unset($this->users[$conn->resourceId]);
	}

	public function onMessage(ConnectionInterface $from,  $data) {
		$data = json_decode($data);
		$type = $data->type;
		switch ($type) {
			case 'chat':
				$chat_msg = $data->chat_msg;

				//подключение к БД
				$db_host = 'localhost';
				$db_database = 'likes';
				$db_user = 'admin';
				$db_pass = '123456';
				$link = mysql_connect($db_host, $db_user, $db_pass);
				mysql_select_db($db_database, $link) or die("Невозможно выбрать базу данных: ".mysql_error());
				mysql_query("SET names UTF8");
				
				//обновление количества Likes
				$result = mysql_query("SELECT likke FROM cart WHERE id='$chat_msg'", $link);
				if(mysql_num_rows($result) > 0){
					$row = mysql_fetch_array($result);
					$new_count = $row["likke"] + 1;
					$update = mysql_query("UPDATE cart SET likke='$new_count' WHERE id='$chat_msg'", $link);
				} else {
					$result = mysql_query("SELECT likke FROM cart WHERE id='$chat_msg'", $link);
					$row = mysql_fetch_array($result);
					$cnt_crt = 1;
					$update = mysql_query("UPDATE cart SET likke='$cnt_crt' WHERE id='$chat_msg'", $link);
				}
				
				//ответ клиенту
				$from->send(json_encode(array("type"=>$type,"msg"=>$chat_msg)));
				//обновление likes у других клиентов
				foreach($this->clients as $client){
					if($from!=$client){
						$client->send(json_encode(array("type"=>$type,"msg"=>$chat_msg)));
					}
				}
				
				break;
		}
	}

	public function onError(ConnectionInterface $conn, \Exception $e) {
		$conn->close();
	}
}
$server = IoServer::factory(
	new HttpServer(new WsServer(new Chat())),
	8080
);
$server->run();
?>