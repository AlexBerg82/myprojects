<?php
$session = mt_rand(1,999);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Chat</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	
	<link rel="stylesheet" type="text/css" href="css/main.css"/>

	<script src="js/jquery.js" type="text/javascript"></script>
	
	<link href="mixitup/style.css" rel="stylesheet"/>
</head>
<body>
	<div class="wrapper">

		<div class="card-block">
			<ul class="container card-c1">
				<li class="mix" id="li1" data-edited="">
					<a href="">
						<div class="title-card">
							<p>1</p>
						</div>
					</a>
					<div class="like">
						<a href="#" class="chat_input" id="1"></a>
						<p class="cart" id="rsp1"></p>
					</div>
				</li>
				<li class="mix" id="li2" data-edited="">
					<a href="">
						<div class="title-card">
							<p>2</p>
						</div>
					</a>
					<div class="like">
						<a href="#" class="chat_input" id="2"></a>
						<p class="cart" id="rsp2"></p>
					</div>
				</li>
				<li class="mix" id="li3" data-edited="">
					<a href="">
						<div class="title-card">
							<p>3</p>
						</div>
					</a>
					<div class="like">
						<a href="#" class="chat_input" id="3"></a>
						<p class="cart" id="rsp3"></p>
					</div>
				</li>
				<li class="mix" id="li4" data-edited="">
					<a href="">
						<div class="title-card">
							<p>4</p>
						</div>
					</a>
					<div class="like">
						<a href="#" class="chat_input" id="4"></a>
						<p class="cart" id="rsp4"></p>
					</div>
				</li>
				<li class="mix" id="li5" data-edited="">
					<a href="">
						<div class="title-card">
							<p>5</p>
						</div>
					</a>
					<div class="like">
						<a href="#" class="chat_input" id="5"></a>
						<p class="cart" id="rsp5"></p>
					</div>
				</li>
				<li class="mix" id="li6" data-edited="">
					<a href="">
						<div class="title-card">
							<p>6</p>
						</div>
					</a>
					<div class="like">
						<a href="#" class="chat_input" id="6"></a>
						<p class="cart" id="rsp6"></p>
					</div>
				</li>
			</ul>
		</div>
	</div>
		
		
		
	<script>
	
	function viewLike(){
		$.ajax({
			url: 'include/loadlike-def.php',
			type: 'post',
			dataType:'json',
			success: function(data){
				for(var i = 0; i<data.length; i++){
					$("#rsp"+(i+1)).html(data[i]['likke']);
					$("#li"+(i+1)).attr('data-edited',data[i]['likke']);
				}

				var containerEl = document.querySelector('.container');
				var mixer = mixitup(containerEl, {
					behavior: {liveSort: true},
					load: {sort: 'edited:desc'}
				});
			}
		});

	}
	viewLike();

	
	jQuery(function($){
		// Websocket
		var websocket_server = new WebSocket("ws://localhost:8080/");
		websocket_server.onopen = function(e){
			websocket_server.send(
				JSON.stringify({
					'type':'socket',
					'user_id':<?php echo $session; ?>
				})
			);
		};
		websocket_server.onerror = function(e){
			// Errorhandling
		}
		websocket_server.onmessage = function(e){
			var json = JSON.parse(e.data);
			switch(json.type){
				case 'chat':
					$.ajax({
						type: 'POST',
						url: 'include/loadlike.php',
						data: "id="+json.msg,
						dataType: 'html',
						cache: false,
						success: function(data){
							$('#rsp'+json.msg).html(data);

							setTimeout(function() {
								var el = $('#li'+json.msg);
								var target = el[0];
								target.setAttribute('data-edited', data);
								var containerEl = document.querySelector('.container');
								var mixer = mixitup(containerEl, {
									behavior: {liveSort: true},
									load: {sort: 'edited:desc'}
								});
								mixer.sort('edited:desc').then(function(state){
									//state.targets[0] === target; // true
								});
							}, 5000);
						}
					});
					
					break;
			}
		}
		// Events
		$('.chat_input').on('click',function(e){
			var chat_msg = $(this).attr('id');
			websocket_server.send(
				JSON.stringify({
					'type':'chat',
					'user_id':<?php echo $session; ?>,
					'chat_msg':chat_msg
				})
			);
		});
	});
	</script>
	
	
	<script src="mixitup/mixitup.js"></script>
</body>
</html>